export const hugging_face_key = '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'
export const cloudinaryCloudname = "dmm8zr0az"
export const sightengine_api_user = "491630136"
export const sightengine_api_secret = "C4MoxqQPspV7jVvMv728pcy2sTpjDe9A"
export const sightengine_workflow = "wfl_g5fdiHz4maLRX7ezhd867"
export const sightengine_listID = "tli_g5t6wWqDfOy6QW00gUBbQ"
export const elevenlabs_api_key = "sk_bcaec6b779e279d180e2b3197cecbd0f08d5795822bb4f3b"
